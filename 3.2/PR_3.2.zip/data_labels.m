function [data, class_labels] = data_labels(nr_of_classes)  
  load lab3_2.mat;
  data = lab3_2;
  
  if nr_of_classes == 2
    class_labels = floor( (0:length(data)-1) * nr_of_classes / length(data) );
  elseif nr_of_classes == 4
    fac = length(data)/nr_of_classes;
    for k = (0:nr_of_classes-1)
      left = 1 + k*fac;
      right = (k+1)*fac;
      class_labels(left:right) = k+1;
    end
  else
    error('number of classes must be either 2 or 4')
  end