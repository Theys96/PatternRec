function val = Psi(a,b)
%PSI Returns 1 if inputs are equal, -1 otherwise
    if a == b
        val = 1;
    else
        val = -1;
    end
end

